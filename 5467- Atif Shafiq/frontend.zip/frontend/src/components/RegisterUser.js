import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const RegisterUser = () => {
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [formErr, setFormErr] = useState({});

  const formValidation = () => {
    let err = {};
    if (name === "") {
      err.name = "name is required";
    }
    if (email === "") {
      err.email = "email is required";
    }
    if (password === "") {
      err.password = "password is required";
    }
    setFormErr({ ...err });
    return Object.keys(err) < 1;
  };
  const handleSubmit = async (e) => {
    console.log("form submission");
    e.preventDefault();

    let isValid = formValidation();

    if (isValid) {
      let data = await fetch(`http://127.0.0.1:5001/register`, {
        method: "POST",
        body: JSON.stringify({ name, email, password }),
        headers: {
          "content-type": "application/json",
        },
      });
      navigate("/userLogin");
      data = await data.json();
    } else {
      alert("Please fill all the information");
    }
  };
  return (
    <div>
      <div class="p-4">
        <div class="container">
          <div class="row">
            <div class="col-md-5 col-sm-6 col-lg-3 mx-auto">
              <div class="formContainer">
                <h2 class="p-2 text-center text-white h4" id="formHeading">
                  Registration
                </h2>

                <form onSubmit={handleSubmit}>
                  <div class="form-group mt-3">
                    <label class="mb-2" for="username">
                      Your Name
                    </label>
                    <input
                      class="form-control"
                      id="username"
                      name="username"
                      type="text"
                      placeholder="Enter your Name"
                      onChange={(e) => setName(e.target.value)}
                    />
                  </div>
                  <div class="form-group mt-3">
                    <label class="mb-2" for="username">
                      Email ID
                    </label>
                    <input
                      class="form-control"
                      id="username"
                      name="username"
                      type="email"
                      placeholder="Enter your email"
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </div>
                  <div class="form-group mt-3">
                    <label class="mb-2" for="password">
                      Password
                    </label>
                    <input
                      class="form-control"
                      id="password"
                      name="password"
                      placeholder="Enter Password"
                      onChange={(e) => setPassword(e.target.value)}
                    />
                  </div>
                  <div class="mt-3">
                    <input type="checkbox" /> Remember me
                  </div>
                  <button
                    type="submit"
                    class="btn btn-outline-primary btn-lg w-100 mt-4"
                  >
                    Register Now
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RegisterUser;
