import React, { useState } from "react";
import "./UserLogin.css";
import { useNavigate } from "react-router-dom";

const UserLogin = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState({
    email: "",
    password: "",
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    let data = await fetch(`http://localhost:5001/register/${user.email}`);
    data = await data.json();
    if (data.email === user.email) {
      if (data.password === user.password) {
        localStorage.setItem("user", JSON.stringify(data));
        navigate("/");
      } else {
        alert("Please enter correct password");
      }
    } else {
      alert("User not found");
    }
  };

  return (
    <div>
      <div class="p-4">
        <div class="container">
          <div class="row">
            <div class="col-md-5 col-sm-6 col-lg-3 mx-auto">
              <div class="formContainer">
                <h2 class="p-2 text-center text-white h4" id="formHeading">
                  Login
                </h2>

                <form onSubmit={handleSubmit}>
                  <div class="form-group mt-3">
                    <label class="mb-2" for="username">
                      Email ID
                    </label>
                    <input
                      class="form-control"
                      id="username"
                      name="username"
                      type="email"
                      placeholder="Enter your email"
                      onChange={(e) => {
                        setUser({ ...user, email: e.target.value });
                      }}
                    />
                  </div>
                  <div class="form-group mt-3">
                    <label class="mb-2" for="password">
                      Password
                    </label>
                    <input
                      class="form-control"
                      id="password"
                      name="password"
                      placeholder="Enter Password"
                      onChange={(e) => {
                        setUser({ ...user, password: e.target.value });
                      }}
                    />
                  </div>
                  <div class="mt-3">
                    <input type="checkbox" /> Remember me
                  </div>
                  <button
                    type="submit"
                    class="btn btn-outline-primary btn-lg w-100 mt-4"
                  >
                    Login
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserLogin;
