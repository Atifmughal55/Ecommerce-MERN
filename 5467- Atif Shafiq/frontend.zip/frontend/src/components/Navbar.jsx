import React from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";

const Navbar = () => {
  const auth = localStorage.getItem("user");
  const navigate = useNavigate();

  const logout = () => {
    localStorage.clear();
    navigate("/userLogin");
  };
  const state = useSelector((state) => state.handleCart);
  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-light bg-white py-3 shadow-sm">
        <div className="container">
          <h3 className="navbar-brand">eMart</h3>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div
            className="collapse navbar-collapse f-flex justify-content-end"
            id="navbarSupportedContent"
          >
            {auth ? (
              <div className="col-lg d-flex">
                <ul className="navbar-nav mx-auto mb-2 mb-lg-0">
                  <li className="nav-item">
                    <NavLink
                      className="nav-link active"
                      aria-current="page"
                      to="/"
                    >
                      Home
                    </NavLink>
                  </li>
                  <li className="nav-item">
                    <NavLink className="nav-link" to="/products">
                      Products
                    </NavLink>
                  </li>
                  <li className="nav-item">
                    <NavLink className="nav-link" to="/about">
                      About
                    </NavLink>
                  </li>
                  <li className="nav-item">
                    <NavLink className="nav-link" to="contact">
                      Contact Us
                    </NavLink>
                  </li>
                </ul>
                <p>{auth.name}</p>
                <NavLink className="btn btn-outline-dark ms-2" to="/cart">
                  <i className="fa fa-shopping-cart me-1"></i> Cart (
                  {state.length})
                </NavLink>
                <button className="btn btn-outline-dark ms-2" onClick={logout}>
                  <i className="fa fa-shopping-cart me-1"></i> LogOut
                </button>
              </div>
            ) : (
              <div clascName="buttons">
                <NavLink className="btn btn-outline-dark" to="/userLogin">
                  <i className="fa fa-sign-in me-1"></i> Login
                </NavLink>
                <NavLink
                  className="btn btn-outline-dark ms-2"
                  to="/userRegister"
                >
                  <i className="fa fa-user-plus me-1"></i> Register
                </NavLink>
              </div>
            )}
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Navbar;
