import "./App.css";
import Home from "./Pages/Home";
import Navbar from "./components/Navbar";
import { Routes, Route } from "react-router-dom";
import Products from "./Pages/Products";
import Product from "./components/Product";
import Cart from "./components/Cart";
import Checkout from "./components/Checkout";
import About from "./Pages/About";
import Contact from "./Pages/Contact";
import Admin from "./components/Admin";
import UserLogin from "./components/UserLogin";
import RegisterUser from "./components/RegisterUser";
import ProtectedRoute from "./components/ProtectedRoute";
import Footer from "./components/Footer";
function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route element={<ProtectedRoute />}>
          <Route path="/" element={<Home />} />
          <Route path="/products" element={<Products />} />
          <Route path="/products/:id" element={<Product />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
        </Route>
        <Route path="/admin" element={<Admin />} />
        <Route path="/userLogin" element={<UserLogin />} />
        <Route path="/userRegister" element={<RegisterUser />} />
      </Routes>
      <Footer />
    </>
  );
}

export default App;
