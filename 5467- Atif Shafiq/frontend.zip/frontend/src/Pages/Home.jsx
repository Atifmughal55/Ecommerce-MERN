import React from "react";
import Products from "./Products";
import { Link } from "react-router-dom";

const Home = () => {
  return (
    <div className="hero">
      <div class="card bg-dark text-white border-0 ">
        <img
          src="https://images.unsplash.com/photo-1591085686350-798c0f9faa7f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1031&q=80"
          class="card-img"
          alt="background image"
          height="550px"
        />
        <div class="card-img-overlay d-flex flex-column justify-content-center">
          <div className="container">
            <h5 class="card-title display-3 fw-bolder text-outline mb-0">
              NEW SEASON ARIVALS
            </h5>
            <p class="card-text lead fs-2">CHECK OUT ALL THE NEW TRANDS</p>
          </div>
        </div>
      </div>
      <div class="b-example-divider"></div>
      <div class="container col-xxl-8 px-4 py-5">
        <div class="row flex-lg-row-reverse align-items-center g-5 py-5">
          <div class="col-10 col-sm-8 col-lg-6">
            <img
              src="https://yandex-images.clstorage.net/k55TxB098/8ff322-_/-HOsHkd51SZWE11Ii-J4_4GFsVDKoPNIc-SEzegjro26f-ROaRbZMBK2omi6-9OVpRdrACjgXrdswvJg1Cdezh1ynFoDvWEX84aJaf6i-M_RpGSE-7E26DY1IOgtd_stes_xLbqBvlIUcRFqCNkEAQViG2BsFIviqUSEofHAOshKEC5uVmrWoNdDLm5L80uMYuRWIkpBhriHJZY5T-Sujo479114Ez4QpWDQyQvrFmL3MDhTf4P6QzgWBfTz8jope3NezYVItsKX0F3dW9Moz9HFdtKr8PdKpCbn6n7nvk7-CmSeCSCOYmbhkzhoOTbCpDF7k53CiQPLN_U1s7CZOpnw_N90GIdylhHu7zjDSb6wxvViStI1-_VWZlqcxd4OzXmEzQmTjwMVIUFaWHsnQEVjiWKPgrrSyUbVFXMSyWhZQgz9JYn0U6bjvh07YIoOs0bWEBlQhctFBxX6XfSd39wb1p1q8U0xFMNi-enbhCLloqtBbtBLcGnkNUWAANkLSoHuj-RYdTJmYB3u-jAKXmPkRDKIM4SI1VVWuCzGn96PCZR_e7IskKbRsVpIa6eAJ2CLMswT6vFKBHW0cfCI6IhwX3-3G_ZSlgI-TvsQeKzSxTXCW9GX6DcVNPj_Rp_f_Xi3DUgRz8NHMaB4eLrlkGUAuoC8g0iSa0XG1nETKZm5454vlcpGAuQh_W_pcikPYcU2kBmwNvum9AQqfWZOvr2Jt575057DlVMxGmj5hDIlwHhjLpLrcUu2V0WA8ysLeHH-r_fIpwPks3xfykCo_uFk5YAJYyXYRLRE-E7mDk79KeQOaBPuExfikXnKWwYC1mArES_BWIIbBEf0YHE5aXrzrW1nqMWQNAMOz1jQG0-A5mcCqJMHyZYFVZttRXx-jrmnvSkyD-GVQOEK-skEIFXgqgNvgEtjeOXVF1MACyuq4v1MBZgUkDWTXJwqQjkcQyUHgKqxVVokl0XbXIfvo"
              class="d-block mx-lg-auto img-fluid"
              alt="Bootstrap Themes"
              width="700"
              height="500"
              loading="lazy"
            />
          </div>
          <div class="col-lg-6">
            <h1 class="display-5 fw-bold lh-1 mb-3">
              Discover Limitless Possibilities: Shop Your Dreams
            </h1>
            <p class="lead">
              Welcome to our ecommerce website, where you can embark on a
              journey of endless possibilities. Prepare to immerse yourself in a
              world of discovery, where every click opens up new horizons and
              brings you closer to realizing your dreams. We have curated a
              diverse collection of products that cater to your unique desires,
              whether it's finding that perfect outfit, upgrading your home
              decor, or exploring the latest tech innovations.
            </p>
            <div class="d-grid gap-2 d-md-flex justify-content-md-start">
              <Link
                to="/products"
                type="button"
                class="btn btn-primary btn-lg px-4 me-md-2"
              >
                Check Now
              </Link>
            </div>
          </div>
        </div>
        <div class="b-example-divider"></div>

        <div class="b-example-divider"></div>
        <div class="row flex-lg-row-reverse align-items-center g-5 py-5">
          <div class="col-lg-6">
            <h1 class="display-5 fw-bold lh-1 mb-3">
              Shop Now and enjoy the Hot deals of this summer
            </h1>
            <p class="lead">
              This summer enjoy the best deals in our store and tell your
              friends to avail this opportunity. <br />
              No need to come in these sunny days save your time for your
              beloves
            </p>
            <div class="d-grid gap-2 d-md-flex justify-content-md-start">
              <Link
                to="/products"
                type="button"
                class="btn btn-primary btn-lg px-4 me-md-2"
              >
                Check Now
              </Link>
            </div>
          </div>
          <div class="col-10 col-sm-8 col-lg-6">
            <img
              src="https://onlineshoppinginpakistanjuniba.files.wordpress.com/2018/07/cropped-online-shopping-in-pakistan-juniba-pk.png"
              class="d-block mx-lg-auto img-fluid"
              alt="Bootstrap Themes"
              width="700"
              height="500"
              loading="lazy"
            />
          </div>
        </div>
      </div>
      <div
        class=" text-secondary text-center"
        style={{
          backgroundImage:
            "url(" +
            "https://images.pexels.com/photos/1050244/pexels-photo-1050244.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" +
            ")",
          backgroundPosition: "center",
          backgroundSize: "cover",
          backgroundRepeat: "no-repeat",
        }}
      >
        <div class="py-5">
          <h1 class="display-5 fw-bold text-white">Discover your Dreams</h1>
          <div class="col-lg mx-auto">
            <p class="fs-5 mb-4 text-white">
              Discover a World of Shopping Delights at eMart: Your Ultimate
              Online Retail Destination
            </p>
            <div class="d-grid gap-2 d-sm-flex justify-content-sm-center"></div>
          </div>
        </div>
      </div>

      <div class="b-example-divider mb-0"></div>
    </div>
  );
};

export default Home;
