//For add to cart
export const addToCart = (product) => {
  return {
    type: "ADDCART",
    payload: product,
  };
};

//For remove from cart
export const delCart = (product) => {
  return {
    type: "DELITEM",
    payload: product,
  };
};
