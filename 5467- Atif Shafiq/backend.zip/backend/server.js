import express from "express";
import dbConnection from "./config/db.js";
import regUser from "./config/newUser.js";
import addProduct from "./config/addProduct.js";
import bodyParser from "body-parser";
// import cloudinary from "cloudinary.v2";
import multer from "multer";
import path from "path";
import cors from "cors";
const app = express();
const PORT = 5001;
app.use(express.json());
dbConnection();

app.use(cors());
//api route for Register new users.
app.post("/register", async (req, res) => {
  let newUser = new regUser(req.body);
  let result = await newUser.save();
  res.send(result);
});

app.get("/register/:email", async (req, res) => {
  let getUser = await regUser.findOne({ email: req.params.email });

  if (getUser) {
    res.send(getUser);
  } else {
    res.send({ error: "Record not found" });
  }
});

//compare login data with the register data.
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

//image uploading area.....
//Storage settings
// const Storage = multer.diskStorage({
//   destination: "uploads",
//   filename: (req, file, cb) => {
//     cb(null, file.originalname);
//   },
// });

// const upload = multer({
//   storage: Storage,
// });

// app.post("/uploads", upload.single("testImage"), async (req, res) => {

//   new addProduct({
//     title: req.body.title,
//     description: req.body.description,
//     price: req.body.price,
//     category: req.body.category,
//     rating: req.body.rating,
//     quantity: req.body.quantity,
//     image: { data: req.file.fieldname, contentType: "image/jpeg" },
//   }).save();
//   res.send("File saved successfully");
// });

//Cloudinary upload
// Configuration
// cloudinary.config({
//   cloud_name: "dyc5jiyoq",
//   api_key: "137219229871993",
//   api_secret: "sLWPrqqEE1-MEJafVQKtKtvFLHo"
// });

const Storage = multer.diskStorage({
  destination: "uploads",
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    const fileExtension = path.extname(file.originalname);
    const modifiedFilename = uniqueSuffix + fileExtension;
    cb(null, modifiedFilename);
  },
});

const upload = multer({
  storage: Storage,
});

app.post("/uploads", upload.single("testImage"), async (req, res) => {
  const { title, description, price, category, rating, quantity } = req.body;
  const file = req.file;

  new addProduct({
    title,
    description,
    price,
    category,
    rating,
    quantity,
    image: { data: file.filename, contentType: file.mimetype },
  }).save();

  res.send("File saved successfully");
});

app.use("/uploads", express.static("uploads"));

// to get the products form the mongodb
// app.get("/products", async (req, res) => {
//   let product = await addProduct.find();
//   res.send(product);
// });

app.get("/products", async (req, res) => {
  try {
    const products = await addProduct.find();
    const productsWithImageUrls = products.map((product) => {
      return {
        ...product.toObject(),
        imageUrl: `/uploads/${product.image.data}`, // Assuming the images are stored in the "uploads" folder
      };
    });

    res.json(productsWithImageUrls);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
});

//to get the specific product
app.get("/product/:id", async (req, res) => {
  let product = await addProduct.findOne({
    _id: req.params.id,
  });
  res.send(product);
});

// to delete the product
app.delete("/products/:id", async (req, res) => {
  let delProduct = await addProduct.deleteOne({ _id: req.params.id });
  res.send(delProduct);
});

//To  Update the Product
app.listen(PORT, () => {
  console.log(`App is listening on port ${PORT}`);
});
