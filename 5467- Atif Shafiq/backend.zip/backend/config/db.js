import mongoose from "mongoose";

const dbConnection = async () => {
  let conn = await mongoose.connect("mongodb://127.0.0.1:27017/fyproject");
  try {
    console.log(
      `Database connection is established ${mongoose.connection.host}`
    );
  } catch (err) {
    console.log(`Error is Db connection: ${e.message}`);
  }
};

export default dbConnection;
