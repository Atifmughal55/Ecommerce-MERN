import mongoose from "mongoose";
// import encrypt from "mongoose-encryption";
const userSchema = new mongoose.Schema({
  name: String,
  email: String,
  password: String,
});

// const secret = "Thisisourlittlesecret";
// userSchema.plugin(encrypt, { secret: secret, encryptedFields: ["password"] });

export default mongoose.model("registerData", userSchema);
